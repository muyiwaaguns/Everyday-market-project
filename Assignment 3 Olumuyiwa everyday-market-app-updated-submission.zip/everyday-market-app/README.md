# Everyday Market App

A polished Angular 21 standalone application built for the Everyday Market assignment.

## Project structure

- `src/app/shared/` - reusable shared components
- `src/app/market/` - market and category-related components

## Implemented requirements

- Standalone Angular app using Angular 21 package versions
- `Category` interface at `src/app/market/category.ts`
- `App` renders `Header` and `ProductsPage`
- `ProductsPage` stores a hard-coded list of 5 favourite categories
- `CategoryMenu` receives categories through property binding
- `CategoryMenuItem` emits click events upward through `EventEmitter`
- Uses Angular `@for` with `track category.id`
- Custom title, custom SVG artwork, polished styling, and inline documentation

## Commands

```bash
npm install
npm run start
npm run lint
npm run test -- --no-watch
```

## AI assistance note

AI assistance was used to:
- help organize the Angular file structure,
- draft starter code and documentation,
- generate custom SVG assets,
- prepare the testing document outline.

All code should be reviewed and understood before submission.

## Note about environment used for packaging

The container used to package this submission had no public npm registry access, so dependency installation and live command execution could not be completed inside the container. The project files, tests, lint configuration, documentation, assets, and screenshot deliverables are included and ready for installation in a normal Angular development environment.
