import { Routes } from '@angular/router';
import { ProductsPageComponent } from './market/products-page/products-page';
import { RegisterPageComponent } from './market/register-page/register-page';

/**
 * Standalone application routes for Assignment 2.
 * The default route redirects users to the registration page first.
 */
export const appRoutes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'register' },
  { path: 'register', component: RegisterPageComponent },
  { path: 'products', component: ProductsPageComponent },
  { path: '**', redirectTo: 'register' }
];
