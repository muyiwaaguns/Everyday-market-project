import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { ProductsPageComponent } from './products-page';

describe('ProductsPageComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductsPageComponent],
      providers: [provideRouter([])]
    }).compileComponents();
  });

  it('should create the products page', () => {
    const fixture = TestBed.createComponent(ProductsPageComponent);
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('should contain five hard-coded categories', () => {
    const fixture = TestBed.createComponent(ProductsPageComponent);
    expect(fixture.componentInstance.categoryList.length).toBe(5);
  });

  it('should call alert with the selected category name', () => {
    const fixture = TestBed.createComponent(ProductsPageComponent);
    const alertSpy = spyOn(window, 'alert');

    fixture.componentInstance.onCategorySelected({ id: 1, name: 'Fresh Produce' });

    expect(alertSpy).toHaveBeenCalledWith('You selected: Fresh Produce');
  });
});
