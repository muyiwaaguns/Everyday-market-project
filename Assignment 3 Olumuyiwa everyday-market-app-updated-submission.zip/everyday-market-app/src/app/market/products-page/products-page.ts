import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Category } from '../category';
import { CategoryMenuComponent } from '../category-menu/category-menu';

@Component({
  selector: 'app-products-page',
  standalone: true,
  imports: [CategoryMenuComponent, RouterLink],
  templateUrl: './products-page.html',
  styleUrl: './products-page.css'
})
export class ProductsPageComponent {
  /**
   * Hard-coded category list required by the assignment.
   * The names are based on everyday market-style categories.
   */
  readonly categoryList: Category[] = [
    { id: 1, name: 'Fresh Produce' },
    { id: 2, name: 'Bakery' },
    { id: 3, name: 'Household' },
    { id: 4, name: 'Beverages' },
    { id: 5, name: 'Wellness' }
  ];

  onCategorySelected(selectedCategory: Category): void {
    alert(`You selected: ${selectedCategory.name}`);
  }
}
