import { TestBed } from '@angular/core/testing';
import { CategoryMenuItemComponent } from './category-menu-item';

describe('CategoryMenuItemComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CategoryMenuItemComponent]
    }).compileComponents();
  });

  it('should create the category menu item', () => {
    const fixture = TestBed.createComponent(CategoryMenuItemComponent);
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('should emit when clicked', () => {
    const fixture = TestBed.createComponent(CategoryMenuItemComponent);
    const component = fixture.componentInstance;
    const emitSpy = spyOn(component.categoryClicked, 'emit');

    component.handleClick();

    expect(emitSpy).toHaveBeenCalled();
  });
});
