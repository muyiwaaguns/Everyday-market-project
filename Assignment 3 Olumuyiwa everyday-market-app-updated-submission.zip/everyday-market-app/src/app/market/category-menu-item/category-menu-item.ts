import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-category-menu-item',
  standalone: true,
  template: `
    <button type="button" class="menu-item" (click)="handleClick()">
      <span class="menu-item__icon" aria-hidden="true">✦</span>
      <span class="menu-item__label">{{ categoryName }}</span>
      <span class="menu-item__hint">Click to shop</span>
    </button>
  `,
  styles: [`
    .menu-item {
      width: 100%;
      min-height: 160px;
      border: 1px solid rgba(203, 127, 71, 0.18);
      border-radius: 24px;
      background:
        linear-gradient(180deg, rgba(255,255,255,0.96), rgba(255,245,236,0.98));
      box-shadow: 0 14px 28px rgba(70, 44, 24, 0.08);
      padding: 1.1rem;
      display: flex;
      flex-direction: column;
      align-items: start;
      justify-content: space-between;
      gap: 0.8rem;
      color: var(--ink);
      cursor: pointer;
      text-align: left;
      transition: transform 150ms ease, box-shadow 150ms ease, border-color 150ms ease;
    }

    .menu-item:hover,
    .menu-item:focus-visible {
      transform: translateY(-3px);
      box-shadow: 0 18px 28px rgba(70, 44, 24, 0.12);
      border-color: rgba(203, 127, 71, 0.4);
      outline: none;
    }

    .menu-item__icon {
      display: inline-grid;
      place-items: center;
      width: 2.8rem;
      height: 2.8rem;
      border-radius: 999px;
      background: rgba(203, 127, 71, 0.14);
      color: var(--accent-dark);
      font-size: 1.1rem;
    }

    .menu-item__label {
      font-size: 1.35rem;
      font-weight: 700;
    }

    .menu-item__hint {
      color: var(--muted);
      font-size: 0.95rem;
    }
  `]
})
export class CategoryMenuItemComponent {
  // Displays the current category label for a single tile.
  @Input({ required: true }) categoryName = '';
  @Output() readonly categoryClicked = new EventEmitter<void>();

  // Emits the click interaction to the parent CategoryMenu component.
  handleClick(): void {
    this.categoryClicked.emit();
  }
}
