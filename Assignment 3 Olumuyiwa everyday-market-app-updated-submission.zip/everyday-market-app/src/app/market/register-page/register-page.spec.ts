import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { RegisterPageComponent } from './register-page';

describe('RegisterPageComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegisterPageComponent],
      providers: [provideRouter([])]
    }).compileComponents();
  });

  it('should create the register page', () => {
    const fixture = TestBed.createComponent(RegisterPageComponent);
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('should start with submit disabled because the form is invalid', () => {
    const fixture = TestBed.createComponent(RegisterPageComponent);
    fixture.detectChanges();
    const button: HTMLButtonElement = fixture.nativeElement.querySelector('button[type="submit"]');

    expect(button.disabled).toBeTrue();
  });

  it('should become valid when all required values are provided correctly', () => {
    const fixture = TestBed.createComponent(RegisterPageComponent);
    const component = fixture.componentInstance;

    component.registrationForm.setValue({
      name: 'Olumuyiwa Agunbiade',
      email: 'olumuyiwa@example.com',
      phone: '2045551234',
      dateOfBirth: '1995-05-15',
      streetAddress: '123 Main Street',
      province: 'Manitoba',
      country: 'Canada',
      termsAccepted: true
    });

    expect(component.registrationForm.valid).toBeTrue();
  });
});
