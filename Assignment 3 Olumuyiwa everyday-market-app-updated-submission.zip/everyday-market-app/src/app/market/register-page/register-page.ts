import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { canadaOnlyValidator, patternValidator } from '../../shared/validators/custom-validators';

@Component({
  selector: 'app-register-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './register-page.html',
  styleUrl: './register-page.css'
})
export class RegisterPageComponent {
  private readonly formBuilder = inject(FormBuilder);
  private readonly router = inject(Router);

  /**
   * Name regex allows letters and spaces only.
   * Source idea: common character-class pattern /^[A-Za-z ]+$/ used in JS form validation examples.
   */
  private readonly namePattern = /^[A-Za-z ]+$/;

  /**
   * Phone regex enforces exactly 10 digits.
   * Source idea: standard JS anchor pattern /^\d{10}$/.
   */
  private readonly tenDigitPhonePattern = /^\d{10}$/;

  /**
   * Street regex allows letters, numbers, and spaces only.
   * Source idea: standard JS anchor pattern /^[A-Za-z0-9 ]+$/.
   */
  private readonly streetAddressPattern = /^[A-Za-z0-9 ]+$/;

  readonly provinces = [
    'Alberta', 'British Columbia', 'Manitoba', 'New Brunswick', 'Newfoundland and Labrador',
    'Northwest Territories', 'Nova Scotia', 'Nunavut', 'Ontario', 'Prince Edward Island',
    'Quebec', 'Saskatchewan', 'Yukon'
  ];

  readonly countries = ['Canada', 'United States'];

  /**
   * Reactive registration form required by the assignment.
   * Submit stays disabled until the form is valid and Canada is selected.
   */
  readonly registrationForm = this.formBuilder.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(5), patternValidator(this.namePattern, 'lettersAndSpaces')]],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.required, patternValidator(this.tenDigitPhonePattern, 'tenDigits')]],
    dateOfBirth: ['', [Validators.required]],
    streetAddress: ['', [Validators.required, patternValidator(this.streetAddressPattern, 'lettersNumbersSpaces')]],
    province: ['', [Validators.required]],
    country: ['Canada', [Validators.required, canadaOnlyValidator()]],
    termsAccepted: [false, [Validators.requiredTrue]]
  });

  get isCanadaSelected(): boolean {
    return this.registrationForm.controls.country.value === 'Canada';
  }

  isInvalid(controlName: keyof typeof this.registrationForm.controls): boolean {
    const control = this.registrationForm.controls[controlName];
    return control.invalid && control.touched;
  }

  getErrorMessage(controlName: keyof typeof this.registrationForm.controls): string {
    const control = this.registrationForm.controls[controlName];

    if (control.hasError('required')) {
      return 'This field is required.';
    }

    if (control.hasError('minlength')) {
      return 'Please enter at least 5 characters.';
    }

    if (control.hasError('email')) {
      return 'Please enter a valid email address.';
    }

    if (control.hasError('lettersAndSpaces')) {
      return 'Use letters and spaces only.';
    }

    if (control.hasError('tenDigits')) {
      return 'Enter exactly 10 digits.';
    }

    if (control.hasError('lettersNumbersSpaces')) {
      return 'Use letters, numbers, and spaces only.';
    }

    if (control.hasError('canadaOnly')) {
      return 'You must select Canada to continue.';
    }

    if (control.hasError('requiredTrue')) {
      return 'You must accept the Terms & Conditions.';
    }

    return 'Please correct this field.';
  }

  /**
   * Navigates to the products page after a valid submission.
   */
  onSubmit(): void {
    if (this.registrationForm.invalid || !this.isCanadaSelected) {
      this.registrationForm.markAllAsTouched();
      return;
    }

    void this.router.navigate(['/products']);
  }
}
