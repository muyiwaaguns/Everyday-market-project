import { TestBed } from '@angular/core/testing';
import { CategoryMenuComponent } from './category-menu';
import { Category } from '../category';

describe('CategoryMenuComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CategoryMenuComponent]
    }).compileComponents();
  });

  it('should create the category menu', () => {
    const fixture = TestBed.createComponent(CategoryMenuComponent);
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('should emit the selected category', () => {
    const fixture = TestBed.createComponent(CategoryMenuComponent);
    const component = fixture.componentInstance;
    const selectedCategory: Category = { id: 3, name: 'Plants' };
    const emitSpy = spyOn(component.categorySelected, 'emit');

    component.selectCategory(selectedCategory);

    expect(emitSpy).toHaveBeenCalledWith(selectedCategory);
  });
});
