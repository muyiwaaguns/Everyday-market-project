import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Category } from '../category';
import { CategoryMenuItemComponent } from '../category-menu-item/category-menu-item';

@Component({
  selector: 'app-category-menu',
  standalone: true,
  imports: [CategoryMenuItemComponent],
  template: `
    <section class="menu-grid" aria-label="Product categories">
      @for (category of categories; track category.id) {
        <app-category-menu-item
          [categoryName]="category.name"
          (categoryClicked)="selectCategory(category)">
        </app-category-menu-item>
      }
    </section>
  `,
  styles: [`
    .menu-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
      gap: 1rem;
    }
  `]
})
export class CategoryMenuComponent {
  // Input receives the category data from ProductsPage.
  @Input({ required: true }) categories: Category[] = [];
  @Output() readonly categorySelected = new EventEmitter<Category>();

  // Re-emits the selected category back to the parent component.
  selectCategory(category: Category): void {
    this.categorySelected.emit(category);
  }
}
