import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/**
 * Creates a reusable pattern validator for text inputs.
 * Regex sources are standard JavaScript regular-expression patterns.
 */
export function patternValidator(
  regex: RegExp,
  errorKey: string
): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = String(control.value ?? '').trim();

    if (!value) {
      return null;
    }

    return regex.test(value) ? null : { [errorKey]: true };
  };
}

/**
 * Requires the country field to be Canada before the form can submit.
 */
export function canadaOnlyValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    return control.value === 'Canada' ? null : { canadaOnly: true };
  };
}
