import { bootstrapApplication } from '@angular/platform-browser';
import { App } from './app/app';
import { appConfig } from './app/app.config';

// Bootstraps the standalone Angular application with router support.
bootstrapApplication(App, appConfig)
  .catch((error: unknown) => console.error(error));
