const angular = require('angular-eslint');

module.exports = [
  {
    files: ['**/*.ts'],
    processor: angular.processInlineTemplates,
    ...angular.configs.tsRecommended,
    rules: {
      '@angular-eslint/component-class-suffix': [
        'error',
        {
          suffixes: ['Component', 'Page', 'App']
        }
      ],
      '@angular-eslint/directive-class-suffix': 'off'
    }
  },
  {
    files: ['**/*.html'],
    ...angular.configs.templateRecommended
  }
];
