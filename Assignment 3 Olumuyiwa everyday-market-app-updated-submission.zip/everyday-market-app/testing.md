# Everyday Market App - Testing Document

## Student / Personalization
- Personalized header name: **Olumuyiwa Agunbiade**
- Application: **Everyday Market App**
- Framework: **Angular 21 standalone components with routing and reactive forms**

## AI assistance disclosure
AI was used to help:
- refactor the Assignment 1 app into a routed standalone Angular structure,
- explain reactive form validation patterns,
- generate a reusable custom validator,
- improve CSS styling and organize component files,
- draft the testing document and Word summary.

All code was reviewed and organized for understanding before packaging.

## Screenshots
### 1. Registration page
![Registration page](submission-assets/register-page-screenshot.png)

### 2. Validation state in action
![Validation in action](submission-assets/register-validation-screenshot.png)

### 3. Products page after successful submit/navigation
![Products page](submission-assets/products-page-screenshot.png)

## Test steps performed
1. Opened the application and confirmed `/` redirects to `/register`.
2. Confirmed the header shows **Olumuyiwa Agunbiade's Everyday Market** and custom images.
3. Verified the **Register** and **Products** navigation links appear in the header.
4. Left the registration form blank and confirmed the **Submit and View Products** button stays disabled.
5. Touched required fields with invalid input and confirmed invalid fields show a red visual state.
6. Entered an invalid name with unsupported characters and verified the name validator message appears.
7. Entered an invalid email and verified the email validation message appears.
8. Entered a phone number that was not exactly 10 digits and verified the phone validation message appears.
9. Left Date of Birth empty and verified the required validation message appears.
10. Entered an unsupported street address format and verified the street address validation message appears.
11. Left Province unselected and verified the required validation message appears.
12. Changed Country to **United States** and confirmed the custom Canada-only validation blocks submission.
13. Left **Terms & Conditions** unchecked and confirmed submission remains disabled.
14. Entered valid values in all fields, selected **Canada**, checked **Terms & Conditions**, and confirmed the submit button becomes enabled.
15. Submitted the form and verified Angular Router navigation to `/products`.
16. On the products page, clicked category tiles and confirmed the parent alert is triggered with the selected category name.
17. Used the back navigation link to return to `/register`.

## Expected results summary
- Routing works for `/register`, `/products`, and the root redirect `/`.
- The registration form uses **ReactiveFormsModule** and only submits when valid.
- Custom validation blocks non-Canada country selection.
- Invalid touched controls show a clear red border/state.
- Products page is reachable through router navigation after successful form submission.

## Lint and test verification
The project code was updated to support:
- `npm run lint`
- `ng test --no-watch`

In this container session, `npm install` did not complete cleanly enough to finish a full local Angular CLI verification run, so these should be run once dependencies install normally on the target machine before submission.
